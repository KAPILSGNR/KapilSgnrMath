def printmynumber(number):
    print("This is My Number:")
    return number

class Rectangle:
    def __init__(self,length, width):
        self.length=length
        self.width=width


    def getArea(self):
        area= self.length*self.width
        return area

print("Wow! It's Working")
print("This output is from __init__.py file")