from KapilSgnrMath.classes import Box

mybox= Box(10,20,10)
vol= mybox.getVolume()
print(vol)

