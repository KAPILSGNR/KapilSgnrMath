from setuptools import setup

setup(
    name="KapilSgnrMath",
    version="0.0.1",
    author="Kapil Sharma",
    author_email="kapilsirbotany@gmail.com",
    description="A small Math Library for Testing",
    packages=['KapilSgnrMath'],
    install_requires=[],
    )

