from KapilSgnrMath.MyBox import *
from KapilSgnrMath.MyRectangle import *

print("Wow! It's Working")
print("This output is from __init__.py file")
print("MyBox is Imported")
print("MyRectangle is Imported")

def printmynumber(number):
    print("This is My Number: ",number)
    return number




